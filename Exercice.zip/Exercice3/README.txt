Exercice 3: 

1- 

2-

3-

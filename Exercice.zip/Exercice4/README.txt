Exercice 4: 

1- 

2-

3-
